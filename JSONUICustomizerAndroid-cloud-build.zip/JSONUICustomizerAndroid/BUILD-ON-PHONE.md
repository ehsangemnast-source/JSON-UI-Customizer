# Build the APK using only your Android phone

This project includes a GitHub Actions workflow that builds the APK on GitHub's cloud computers. You do not need Android Studio or a PC, but you do need a GitHub account and an internet connection.

1. In your phone browser, sign in to GitHub and create a **new public or private repository**. Give it a name such as `json-ui-customizer`.
2. Upload the *contents* of this project folder to the repository's main branch. Make sure `.github/workflows/build-apk.yml` is included. If the GitHub mobile upload page does not let you upload the `.github` folder, use GitHub's web interface in desktop mode or the GitHub app/site's file creation interface to add `.github/workflows/build-apk.yml` with the contents of that file.
3. Open the repository's **Actions** tab. Select **Build Android APK**, then choose **Run workflow** if it has not started automatically.
4. Wait for the workflow to finish successfully. Open the completed run and download the `JSON-UI-Customizer-APK` artifact.
5. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Tap it to install. If Android asks, allow your browser or file manager to install unknown apps for this installation.

The APK is a debug build for testing, not a Play Store release. Keep your repository private if you do not want the source project publicly visible.
