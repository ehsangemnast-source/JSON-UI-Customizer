# JSON UI Customizer — Android app project

This project wraps the supplied standalone `index.html` in an Android WebView. The image picker is wired to Android's document picker so the page's **Select an in-game screenshot** control can choose an image from the phone.

## Build an APK

1. Install Android Studio on a computer and open this project folder.
2. Allow Android Studio to install the Android SDK Platform 35 and the requested Gradle components.
3. Wait for Gradle sync to finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`). Transfer that APK to your Android phone and install it.

The project needs internet once during the first Gradle sync to download Android build dependencies. The app itself loads the included HTML locally and does not need internet for its current features.

## Notes
- App label: JSON UI Customizer
- Package ID: `com.example.jsonuicustomizer`
- Minimum Android: 6.0 (API 23)
- The uploaded file was HTML content despite its `.zip` filename, so it was included as `index.html`.
